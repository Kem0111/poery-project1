import colorama


print(colorama.Fore.GREEN + 'and in dim text')