# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['poery_project1', 'poery_project1.scripts']

package_data = \
{'': ['*']}

install_requires = \
['colorama>=0.4.6,<0.5.0']

entry_points = \
{'console_scripts': ['say-hello = poery_project1.scripts.say_hello:main']}

setup_kwargs = {
    'name': 'poery-project1',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'kem',
    'author_email': 'diyeqo@icloud.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
